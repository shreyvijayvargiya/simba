import { uploadFileToPolar, base64ToBuffer, getMimeType } from "./fileUpload";

/**
 * Update product in Polar API
 * PATCH /api/polar/products/update
 * Body: { polarProductId: string, name: string, description?: string, prices: Array, bannerImages?: Array<{base64: string, fileName: string}> }
 */
export default async function handler(req, res) {
	if (req.method !== "PATCH") {
		return res.status(405).json({ error: "Method not allowed" });
	}

	try {
		const { polarProductId, name, description, prices, bannerImages } =
			req.body;

		if (
			!polarProductId ||
			!name ||
			!prices ||
			!Array.isArray(prices) ||
			prices.length === 0
		) {
			return res.status(400).json({
				error: "Polar product ID, name, and prices array are required",
			});
		}

		// Get Polar API credentials from environment variables
		const POLAR_ACCESS_TOKEN = process.env.POLAR_ACCESS_TOKEN;
		const POLAR_API_URL = process.env.POLAR_API_URL || "https://api.polar.sh";

		if (!POLAR_ACCESS_TOKEN) {
			return res.status(500).json({
				error: "Polar API credentials not configured",
			});
		}

		// Upload banner images to Polar Files API if provided
		let mediaFileIds = [];
		if (
			bannerImages &&
			Array.isArray(bannerImages) &&
			bannerImages.length > 0
		) {
			try {
				for (const imageData of bannerImages) {
					// Support both new format (object with base64 and fileName) and legacy format (base64 string)
					let base64String, fileName;

					if (typeof imageData === "string") {
						// Legacy format: just a base64 string
						base64String = imageData;
						fileName = `banner-${Date.now()}-${Math.random().toString(36).substring(2, 9)}.png`;
					} else if (imageData.base64) {
						// New format: object with base64 and fileName
						base64String = imageData.base64;
						fileName =
							imageData.fileName ||
							`banner-${Date.now()}-${Math.random().toString(36).substring(2, 9)}.png`;
					} else {
						console.warn("Invalid image data format, skipping:", imageData);
						continue;
					}

					// Validate file size (max 10MB)
					const fileBuffer = base64ToBuffer(base64String);
					if (fileBuffer.length > 10 * 1024 * 1024) {
						console.warn(`File ${fileName} exceeds 10MB limit, skipping`);
						continue;
					}

					const mimeType = getMimeType(base64String, fileName);

					// Upload to Polar
					const fileId = await uploadFileToPolar(
						fileBuffer,
						fileName,
						mimeType,
						POLAR_ACCESS_TOKEN,
						POLAR_API_URL
					);

					mediaFileIds.push(fileId);
				}
			} catch (fileUploadError) {
				console.error(
					"Error uploading banner images to Polar:",
					fileUploadError
				);
				return res.status(500).json({
					error: "Failed to upload banner images",
					details: fileUploadError.message,
				});
			}
		}

		// Transform prices to Polar API format
		// Polar requires amount_type discriminator and uses price_amount/price_currency
		const transformedPrices = prices.map((price) => {
			// Determine amount_type: "fixed" for fixed prices, "custom" for pay-what-you-want
			const amountType =
				price.amount_type || (price.price_amount ? "fixed" : "custom");

			const priceObj = {
				amount_type: amountType,
				price_currency: price.price_currency || price.currency || "usd",
			};

			// For fixed prices, include price_amount
			if (amountType === "fixed") {
				priceObj.price_amount = price.price_amount || price.amount;
			}
			// For custom/pay-what-you-want, include min/max if provided
			else if (amountType === "custom") {
				if (price.min_amount) priceObj.min_amount = price.min_amount;
				if (price.max_amount) priceObj.max_amount = price.max_amount;
			}

			return priceObj;
		});

		// Build request body
		// Note: Polar does NOT allow changing recurring_interval on update
		// So we only update name, description, and prices
		const requestBody = {
			name,
			description: description || undefined,
			prices: transformedPrices,
		};

		// Add media file IDs if we uploaded any banner images
		// Polar expects medias to be an array of UUID strings, not objects
		if (mediaFileIds.length > 0) {
			requestBody.medias = mediaFileIds;
		}

		// Update product in Polar
		const polarResponse = await fetch(
			`${POLAR_API_URL}/v1/products/${polarProductId}`,
			{
				method: "PATCH",
				headers: {
					Authorization: `Bearer ${POLAR_ACCESS_TOKEN}`,
					"Content-Type": "application/json",
				},
				body: JSON.stringify(requestBody),
			}
		);

		if (!polarResponse.ok) {
			const errorData = await polarResponse.json();
			console.dir(errorData, { depth: null });
			return res.status(polarResponse.status).json({
				error: errorData.message || "Failed to update product in Polar",
			});
		}

		const polarProduct = await polarResponse.json();

		// Return the updated product with price IDs and media file IDs
		// Note: Supabase storage is handled by the client-side API (lib/api/products.js)
		return res.status(200).json({
			success: true,
			product: polarProduct,
			// Include the first price ID for checkout link generation
			priceId:
				polarProduct.prices && polarProduct.prices.length > 0
					? polarProduct.prices[0].id
					: null,
			// Include media file IDs for storing in Supabase
			mediaFileIds: mediaFileIds,
		});
	} catch (error) {
		console.error("Error updating product in Polar:", error);
		return res.status(500).json({
			error: "Internal server error",
		});
	}
}
